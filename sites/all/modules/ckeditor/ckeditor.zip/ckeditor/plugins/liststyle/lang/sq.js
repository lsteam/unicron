/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'liststyle', 'sq', {
	bulletedTitle: 'Karakteristikat e Listës me Pika',
	circle: 'Rreth',
	decimal: 'Decimal (1, 2, 3, etj.)',
	disc: 'Disk',
	lowerAlpha: 'Alfa të vogla (a, b, c, d, e, etj.)',
	lowerRoman: 'Romake të vogla (i, ii, iii, iv, v, etj.)',
	none: 'Asnjë',
	notset: '<not set>',
	numberedTitle: 'Karakteristikat e Listës me Numra',
	square: 'Katror',
	start: 'Fillimi',
	type: 'Lloji',
	upperAlpha: 'Alfa të mëdha (A, B, C, D, E, etj.)',
	upperRoman: 'Romake të mëdha (I, II, III, IV, V, etj.)',
	validateStartNumber: 'Numri i fillimit të listës duhet të është numër i plotë.'
} );
