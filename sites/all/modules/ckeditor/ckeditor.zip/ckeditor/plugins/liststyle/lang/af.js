/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'liststyle', 'af', {
	bulletedTitle: 'Eienskappe van ongenommerde lys',
	circle: 'Sirkel',
	decimal: 'Desimale syfers (1, 2, 3, ens.)',
	disc: 'Skyf',
	lowerAlpha: 'Kleinletters (a, b, c, d, e, ens.)',
	lowerRoman: 'Romeinse kleinletters (i, ii, iii, iv, v, ens.)',
	none: 'Geen',
	notset: '<nie ingestel nie>',
	numberedTitle: 'Eienskappe van genommerde lys',
	square: 'Vierkant',
	start: 'Begin',
	type: 'Tipe',
	upperAlpha: 'Hoofletters (A, B, C, D, E, ens.)',
	upperRoman: 'Romeinse hoofletters (I, II, III, IV, V, ens.)',
	validateStartNumber: 'Beginnommer van lys moet \'n heelgetal wees.'
} );
